#! /bin/bash

tcplist=("7001" "80" "8080" "8081" "22" "23" "1099" "3306" "5432" "1521" "53" "445" "1433" "3389" "6379") 
udplist=("53" "69" "161" "162" "8161") 
for ip in 172.28.23.{1..255}; do
ping -c 1 -t 1 $ip > /dev/null 2> /dev/null
if [ $? -eq 0 ]; then
echo -e '\n\033[32mall tcp port for opening:\033[0m'
for k in ${tcplist[@]} ;do
nc -w 1 -z -v $ip $k > /dev/null 2> /dev/null
[ $? -eq 0 ] && echo $ip tcp port $k is open
done
echo -e '\n\033[32mall udp port for opening:\033[0m'
for s in ${udplist[@]} ; do
nc -u -w 1 -z -v $ip $s > /dev/null 2> /dev/null
[ $? -eq 0 ] && echo $ip udp port $s is open
done
echo -e '\n--------------------------------------- \n'
fi
done
